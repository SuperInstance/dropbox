"""PROTOTYPE. The three custody tiers as signature arithmetic.

This is the counting argument only: who can complete two conflicting steps, and who can stall.
It is NOT a consensus protocol. There is no network, no timing and no leader change.

  single     one custodian signs alone        detect and blame afterwards
  unanimous  every claimant signs each step   forks impossible, any one signer can stall
  quorum     2f+1 of n=3f+1 sign each step    forks impossible up to f liars, survives f stalls
"""
from itertools import product

from .core import Key, oid, sig_ok


class Signer:
    def __init__(self, name, kind="honest"):
        self.key, self.kind, self.signed = Key(name), kind, {}

    def ask(self, step):
        if self.kind == "stalled":
            return None
        sid = oid(step)
        if self.kind == "honest":
            if self.signed.setdefault(step["seq"], sid) != sid:
                return None                      # an honest signer never signs two steps at one seq
        return self.key.sign(sid)


def complete(step, sigs, pubs, mode):
    valid = sum(1 for p in pubs if p in sigs and sig_ok(p, oid(step), sigs[p]))
    if mode == "single":
        return True
    if mode == "unanimous":
        return valid == len(pubs)
    f = (len(pubs) - 1) // 3
    return valid >= 2 * f + 1


def _collect(step, signers):
    return {s.key.pub: sig for s in signers if (sig := s.ask(step)) is not None}


def best_fork(n, byzantine, mode):
    """Can a lying custodian get two conflicting steps both completed? Tries every way of
    choosing which honest signer is shown which step first."""
    x, y = {"seq": 7, "holder": "alice"}, {"seq": 7, "holder": "bob"}
    honest = n - byzantine
    for shown_x_first in product((True, False), repeat=honest):
        signers = [Signer(f"s{i}", "byzantine" if i < byzantine else "honest") for i in range(n)]
        pubs = [s.key.pub for s in signers]
        first_x = signers[:byzantine] + [s for s, fx in zip(signers[byzantine:], shown_x_first) if fx]
        first_y = signers[:byzantine] + [s for s, fx in zip(signers[byzantine:], shown_x_first) if not fx]
        sx, sy = _collect(x, first_x), _collect(y, first_y)
        sx.update(_collect(x, first_y)); sy.update(_collect(y, first_x))   # then ask everyone else too
        if complete(x, sx, pubs, mode) and complete(y, sy, pubs, mode):
            return True
    return False


def progresses(n, stalled, mode):
    signers = [Signer(f"s{i}", "stalled" if i < stalled else "honest") for i in range(n)]
    step = {"seq": 7, "holder": "alice"}
    return complete(step, _collect(step, signers), [s.key.pub for s in signers], mode)
