"""PROTOTYPE. Rooms, stitches and mechanisms for the quilt room protocol. Throwaway code.

Three things and one rule:
  Room      a key plus a hash-linked, signed, append-only log. Minds, resources and clocks are all rooms.
  Stitch    one object co-signed by every party, committing to each party's log head.
  Mechanism a room with a rule and no mind (Clock, Resource, the archive).
  Rule      every commitment cites its premises by hash, and a mechanism checks the citation.

State lives in memory. Nothing here is hardened: no networking, no key storage, no concurrency.
"""
from __future__ import annotations

import hashlib
import json

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


class Violation(Exception):
    def __init__(self, code, detail="", record=None):
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code, self.detail, self.record = code, detail, record


# ------------------------------------------------------------------ hashes, keys, merkle

def canon(o) -> bytes:
    return json.dumps(o, sort_keys=True, separators=(",", ":")).encode()


def Hb(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def H(o) -> str:
    return Hb(canon(o))


def oid(o) -> str:
    """Identity of a signed object: the hash of everything except its signatures."""
    return H({k: v for k, v in o.items() if k not in ("sig", "sigs")})


class Key:
    def __init__(self, seed: str):
        self._sk = Ed25519PrivateKey.from_private_bytes(hashlib.sha256(seed.encode()).digest())
        self.pub = self._sk.public_key().public_bytes_raw().hex()

    def sign(self, digest: str) -> str:
        return self._sk.sign(bytes.fromhex(digest)).hex()


def sig_ok(pub, digest, sig) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub)).verify(bytes.fromhex(sig), bytes.fromhex(digest))
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def _levels(leaves):
    lvl = list(leaves) or [Hb(b"")]
    out = [lvl]
    while len(lvl) > 1:
        if len(lvl) % 2:
            lvl = lvl + [lvl[-1]]
        lvl = [Hb(bytes.fromhex(lvl[i] + lvl[i + 1])) for i in range(0, len(lvl), 2)]
        out.append(lvl)
    return out


def merkle_root(leaves) -> str:
    return _levels(leaves)[-1][0]


def merkle_path(leaves, i):
    path = []
    for lvl in _levels(leaves)[:-1]:
        if len(lvl) % 2:
            lvl = lvl + [lvl[-1]]
        path.append((lvl[i ^ 1], bool(i & 1)))
        i //= 2
    return path


def merkle_check(root, leaf, path) -> bool:
    h = leaf
    for sibling, sibling_is_left in path:
        h = Hb(bytes.fromhex(sibling + h if sibling_is_left else h + sibling))
    return h == root


# ------------------------------------------------------------------ storage with leases

class Store:
    """Content-addressed store. A lease of None means keep forever. Expiry leaves a tombstone;
    loss (drop) leaves nothing, which is the difference between 'expired' and 'unknown'."""

    def __init__(self):
        self.items, self.lease, self.tomb = {}, {}, {}

    def put(self, obj, until=None, key=None):
        k = key or oid(obj)
        fresh = k not in self.items
        self.items[k] = obj
        if fresh:
            self.lease[k] = until
        else:
            self.extend(k, until)
        return k

    def get(self, k):
        return self.items.get(k)

    def status(self, k):
        return "live" if k in self.items else "expired" if k in self.tomb else "unknown"

    def extend(self, k, until):
        if k in self.items and self.lease[k] is not None:
            self.lease[k] = None if until is None else max(self.lease[k], until)

    def gc(self, tick):
        for k in [k for k, u in self.lease.items() if u is not None and u < tick]:
            self.tomb[k] = self.lease.pop(k)
            del self.items[k]

    def drop(self, k):
        self.items.pop(k, None)
        self.lease.pop(k, None)


# ------------------------------------------------------------------ logs

def make_entry(key, seq, prev, kind, body):
    e = {"room": key.pub, "seq": seq, "prev": prev, "kind": kind, "body": body}
    e["sig"] = key.sign(oid(e))
    return e


def check_entry(e):
    if not sig_ok(e["room"], oid(e), e.get("sig", "")):
        raise Violation("bad-signature", f"entry seq {e.get('seq')}")


def verify_view(view):
    """A view is what a room shows: oldest first, starting at genesis or at a declared compaction."""
    for i, e in enumerate(view):
        check_entry(e)
        if i and (e["prev"] != oid(view[i - 1]) or e["seq"] != view[i - 1]["seq"] + 1):
            raise Violation("broken-chain", f"at seq {e['seq']}")
    if view and view[0]["kind"] != "compact" and view[0]["prev"] is not None:
        raise Violation("broken-chain", "view starts mid-log without a declared compaction")


def trace_back(compact_entry, resolve):
    """Check a compaction against its pre-images. Returns them, or None if they cannot be produced."""
    ids, cur = [], compact_entry["prev"]
    for _ in range(compact_entry["body"]["covers"]):
        e = resolve(cur)
        if e is None or oid(e) != cur:
            return None
        check_entry(e)
        ids.append(cur)
        cur = e["prev"]
    ids.reverse()
    if merkle_root(ids) != compact_entry["body"]["root"]:
        raise Violation("compaction-mismatch")
    return [resolve(i) for i in ids]


def ancestry(resolve, head, target) -> str:
    """Is target in the chain ending at head? verified / refuted / unverifiable (pre-images missing)."""
    cur = head
    while cur is not None:
        if cur == target:
            return "verified"
        e = resolve(cur)
        if e is None or oid(e) != cur:
            return "unverifiable"
        check_entry(e)
        cur = e["prev"]
    return "refuted"


def equivocation(e1, e2) -> bool:
    """Two validly signed entries from one room at one sequence number. Self-contained proof."""
    return (e1["room"] == e2["room"] and e1["seq"] == e2["seq"] and oid(e1) != oid(e2)
            and sig_ok(e1["room"], oid(e1), e1["sig"]) and sig_ok(e2["room"], oid(e2), e2["sig"]))


def order_refutes(early_receipt, early_stitch, late_receipt, late_stitch) -> bool:
    """Backdating shown from two receipts alone: the room logged late_stitch after early_stitch,
    yet claims a time for it before the tick early_stitch already cites."""
    for r, s in ((early_receipt, early_stitch), (late_receipt, late_stitch)):
        if not sig_ok(r["room"], oid(r), r["sig"]) or r["body"].get("stitch") != oid(s):
            return False
    return (early_receipt["room"] == late_receipt["room"]
            and late_receipt["seq"] > early_receipt["seq"]
            and early_stitch["after"] is not None and late_stitch["claimed_time"] is not None
            and late_stitch["claimed_time"] < early_stitch["after"]["tick"])


class Room:
    def __init__(self, name, seed=None):
        self.name = name
        self.key = Key(seed or name)
        self.pub = self.key.pub
        self.store = Store()          # this room's own disk
        self.head, self.seq = None, 0
        self.seen = {}                # (room, seq) -> entry: other rooms' receipts this room holds
        self.alarms = []              # equivocation proofs
        self.last_stitch = None
        self.dead = False
        self.mind = None              # whatever currently occupies the room; the protocol never reads it

    def append(self, kind, body):
        e = make_entry(self.key, self.seq, self.head, kind, body)
        self.head = self.store.put(e)
        self.seq += 1
        return e

    def note(self, text):
        raw = Hb(text.encode())
        self.store.put(text, key=raw)
        return self.append("note", {"narrative": raw})

    def view(self):
        out, cur = [], self.head
        while cur is not None:
            e = self.store.get(cur)
            if e is None:
                break
            out.append(e)
            if e["kind"] == "compact":
                break
            cur = e["prev"]
        return out[::-1]

    def compact(self, summary, carried=(), floor=0):
        """Declared rewrite: 'this summary replaces the entries under this root'."""
        ids = [oid(e) for e in self.view()]
        raw = Hb(summary.encode())
        self.store.put(summary, key=raw)
        return self.append("compact", {"covers": len(ids), "root": merkle_root(ids), "summary": raw,
                                       "carried": sorted(carried), "floor": floor})

    def forget(self, compact_entry):
        """Delete the pre-images a compaction covers from this room's disk. Returns them for hand-off."""
        gone, cur = [], compact_entry["prev"]
        for _ in range(compact_entry["body"]["covers"]):
            e = self.store.get(cur)
            if e is None:
                break
            self.store.drop(cur)
            gone.append(e)
            cur = e["prev"]
        return gone[::-1]

    def consider(self, stitch):
        """Hook run before this room signs. Mechanism rooms put their rule here."""

    def learn(self, entry):
        k = (entry["room"], entry["seq"])
        have = self.seen.get(k)
        if have is entry:
            return None
        if not sig_ok(entry["room"], oid(entry), entry.get("sig", "")):
            return None
        if have is not None and oid(have) != oid(entry):
            self.alarms.append((have, entry))
            return have, entry
        self.seen[k] = entry
        return None


def gossip(a: Room, b: Room):
    """Two rooms compare the receipts they hold. This is where forks surface.
    Returns the first equivocation proof either side finds, or None."""
    proof = None
    for e in list(a.seen.values()):
        proof = b.learn(e) or proof
    for e in list(b.seen.values()):
        proof = a.learn(e) or proof
    return proof


class Clock(Room):
    """Time is a resource and this room is its custodian. A tick attests everything submitted since the last."""

    def __init__(self, name, seed=None):
        super().__init__(name, seed)
        self.n, self.pending, self.attested = 0, [], {}

    def submit(self, h):
        self.pending.append(h)

    def tick(self):
        self.n += 1
        e = self.append("tick", {"n": self.n, "attests": self.pending})
        for h in self.pending:
            self.attested[h] = self.n
        self.pending = []
        return e

    def ref(self):
        return {"clock": self.pub, "tick": self.n, "id": self.head}


class Resource(Room):
    """A log plus a rule: one holder at a time. A claim counts only once this room has co-signed it."""

    def holder(self):
        chain, cur = [], self.head
        while cur is not None:
            e = self.store.get(cur)
            chain.append(e)
            cur = e["prev"]
        who = None
        for e in reversed(chain):
            if e["kind"] == "stitch":
                b = self.store.get(e["body"]["stitch"])["body"]
                who = b["holder"] if b.get("type") == "claim" else None if b.get("type") == "release" else who
        return who

    def consider(self, stitch):
        if stitch["body"].get("type") == "claim" and self.holder() is not None:
            raise Violation("double-claim", f"{self.name} is already held")


class Registry(Room):
    """A witness for other rooms' logs: it signs at most one successor to any log head it is shown.
    With a registry as a party to every claim, a custodian fork is refused, not just detected later.
    (Prototype shortcut: it records at signing time, so a stitch that later fails admission still counts.)"""

    def __init__(self, name, seed=None):
        super().__init__(name, seed)
        self.successor = {}

    def consider(self, stitch):
        sid = oid(stitch)
        for pub, head in stitch["heads"].items():
            if pub != self.pub and self.successor.setdefault((pub, head), sid) != sid:
                raise Violation("fork-refused", "this log head already has a successor on record")


# ------------------------------------------------------------------ stitches

def cite(ref, **asserts):
    return {"ref": ref, "asserts": asserts}


def propose(parties, body, cites=(), after=None, claimed_time=None, valid_by=None, retain_until=None):
    return {"kind": "stitch", "parties": sorted(p.pub for p in parties),
            "heads": {p.pub: p.head for p in parties}, "body": body, "cites": list(cites),
            "after": after, "claimed_time": claimed_time, "valid_by": valid_by,
            "retain_until": retain_until, "sigs": {}}


def sign(stitch, key):
    stitch["sigs"][key.pub] = key.sign(oid(stitch))


SCHEMA = {  # fields a typed commitment must assert about the record it rests on
    "discharge": ("amount", "debtor", "creditor"),
    "transfer": ("amount", "debtor", "creditor"),
}
NOW = object()


class Quilt:
    """The mechanisms of one fleet: archive, citation checker, obligation index, time bounds, lineage.

    There is no global ledger object. `archive` is the fleet's retainer; the ledger is the union of stitches.
    """

    def __init__(self, clock=None, trust_roots=(), require_lineage=False):
        self.clock = clock
        self.archive = Store()
        self.rooms = {}
        self.trust_roots = set(trust_roots)
        self.require_lineage = require_lineage
        self.order, self.births, self.children = [], {}, {}
        self._open, self._floor = {}, {}

    def join(self, *rooms):
        for r in rooms:
            self.rooms[r.pub] = r

    def resolve(self, k):
        hit = self.archive.get(k)
        if hit is not None:
            return hit
        for r in self.rooms.values():       # inside a fleet the disk is shared and nothing is deleted
            hit = r.store.get(k)
            if hit is not None:
                return hit
        return None

    # ---- checks anyone can re-run

    def check(self, s):
        sid = oid(s)
        for p in s["parties"]:
            if p not in s["sigs"]:
                raise Violation("incomplete-signatures", "every party must sign")
            if not sig_ok(p, sid, s["sigs"][p]):
                raise Violation("bad-signature", "stitch")
        self.check_citations(s)
        self.check_time(s)
        self.check_rules(s)
        return sid

    def check_citations(self, s):
        for c in s["cites"]:
            if self.archive.status(c["ref"]) == "expired":
                raise Violation("expired-citation", c["ref"][:12])
            obj = self.resolve(c["ref"])
            if obj is None:
                raise Violation("unresolved-citation", c["ref"][:12])
            record = obj.get("body", {}) if isinstance(obj, dict) else {}
            for k, v in c["asserts"].items():
                if record.get(k) != v:
                    raise Violation("citation-mismatch", f"{k}: asserted {v!r}, record says {record.get(k)!r}",
                                    record=record)
        need = SCHEMA.get(s["body"].get("type"))
        if need and not any(all(k in c["asserts"] for k in need) for c in s["cites"]):
            raise Violation("citation-incomplete", f"{s['body']['type']} must assert {', '.join(need)}")

    def check_time(self, s):
        a = s["after"]
        if a is not None:
            t = self.clock.store.get(a["id"]) if self.clock and a["clock"] == self.clock.pub else None
            if t is None or t["kind"] != "tick" or t["body"]["n"] != a["tick"] or t["room"] != a["clock"]:
                raise Violation("bad-clock-ref")
            check_entry(t)
        if s["claimed_time"] is not None and s["claimed_time"] < self.lower_bound(s):
            raise Violation("time-refuted",
                            f"claims tick {s['claimed_time']}, but its own history is after tick {self.lower_bound(s)}")

    def check_rules(self, s):
        t = s["body"].get("type")
        if t in ("discharge", "transfer"):
            ob = self._open.get(s["cites"][0]["ref"])
            if ob is None:
                raise Violation("not-open", "no open obligation under that citation")
            if t == "transfer":
                if ob["creditor"] not in s["parties"]:
                    raise Violation("novation-needs-creditor")
                if ob["debtor"] not in s["parties"]:
                    raise Violation("not-the-debtor")
        if t == "promote" and self.resolve(s["body"]["raw"]) is None:
            raise Violation("unresolved-citation", "the narrative being promoted is gone")

    # ---- time

    def floor_of(self, pub, head):
        """Latest tick that pub's log, up to head, is provably after."""
        cur, room = head, self.rooms.get(pub)
        while cur is not None and room is not None:
            e = room.store.get(cur)
            if e is None:
                return 0
            if e["kind"] == "compact":
                return e["body"]["floor"]
            if e["kind"] == "stitch":
                sid = e["body"]["stitch"]
                if sid in self._floor:
                    return self._floor[sid]
                prior = self.archive.get(sid)
                return self.lower_bound(prior) if prior else 0
            cur = e["prev"]
        return 0

    def lower_bound(self, s):
        own = s["after"]["tick"] if s["after"] else 0
        return max([own] + [self.floor_of(p, h) for p, h in s["heads"].items()])

    def upper_bound(self, sid):
        """Earliest tick by which sid provably existed: when it, or anything built on it, was attested."""
        if self.clock is None:
            return None
        seen, todo, best = {sid}, [sid], None
        while todo:
            x = todo.pop()
            t = self.clock.attested.get(x)
            if t is not None:
                best = t if best is None else min(best, t)
            for c in self.children.get(x, ()):
                if c not in seen:
                    seen.add(c)
                    todo.append(c)
        return best

    def interval(self, sid):
        return self._floor[sid], self.upper_bound(sid)

    # ---- admission

    def admit(self, s):
        sid = self.check(s)
        rooms = [self.rooms[p] for p in s["parties"]]
        for r in rooms:
            if r.dead:
                raise Violation("dead-room", r.name)
            if s["heads"][r.pub] != r.head:
                raise Violation("stale-head", f"{r.name}'s log has moved on since this was proposed")
        if s["valid_by"] is not None and self.clock.n > s["valid_by"]:
            raise Violation("stitch-expired", f"valid by tick {s['valid_by']}, now {self.clock.n}")
        newborn = s["body"].get("child") if s["body"].get("type") == "birth" else None
        if self.require_lineage:
            for p in s["parties"]:
                if p != newborn:
                    self.lineage(p)

        self._floor[sid] = self.lower_bound(s)
        receipts = {}
        for r in rooms:
            r.store.put(s)
            receipts[r.pub] = r.append("stitch", {"stitch": sid})
            if r.last_stitch:
                self.children.setdefault(r.last_stitch, set()).add(sid)
            r.last_stitch = sid
        for r in rooms:                       # every party keeps every other party's signed receipt
            for other in rooms:
                if other is not r:
                    r.learn(receipts[other.pub])
        self.archive.put(s, until=s["retain_until"])
        self._renew(s, s["retain_until"])
        self.order.append(sid)
        self._apply(self._open, sid, s)
        if newborn:
            self.births[newborn] = sid
        if self.clock:
            self.clock.submit(sid)
        return sid, receipts

    def stitch(self, parties, body, cites=(), after=NOW, **kw):
        if after is NOW:
            after = self.clock.ref() if self.clock and self.clock.n else None
        s = propose(parties, body, cites=cites, after=after, **kw)
        for p in parties:
            p.consider(s)
            sign(s, p.key)
        return self.admit(s)

    def _renew(self, s, until):
        """Citing extends the lease of the cited entry and of everything it cites in turn."""
        for c in s["cites"]:
            cited = self.archive.get(c["ref"])
            if cited is not None:
                self.archive.extend(c["ref"], until)
                self._renew(cited, until)

    # ---- obligations

    @staticmethod
    def _apply(open_, sid, s):
        b = s["body"]
        t = b.get("type")
        if t == "obligation":
            open_[sid] = {k: b[k] for k in ("debtor", "creditor", "amount", "due", "what")}
        elif t == "discharge":
            open_.pop(s["cites"][0]["ref"], None)
        elif t == "transfer" and s["cites"][0]["ref"] in open_:
            open_[s["cites"][0]["ref"]]["debtor"] = b["to"]

    def obligations(self):
        """Recomputed from the stitches every time. Balances are never stored."""
        open_ = {}
        for sid in self.order:
            s = self.archive.get(sid)
            if s is not None:
                self._apply(open_, sid, s)
        return open_

    def due(self, tick):
        return [(sid, o) for sid, o in self._open.items() if o["due"] <= tick]

    # ---- lifecycle

    def compact(self, room, summary):
        """The mind writes the summary. The mechanism writes what must survive it."""
        carried = [sid for sid, o in self._open.items() if room.pub in (o["debtor"], o["creditor"])]
        return room.compact(summary, carried=carried, floor=self.floor_of(room.pub, room.head))

    def birth(self, parent, child):
        if child.head is not None:
            raise Violation("already-born", child.name)
        self.join(child)
        return self.stitch([parent, child], {"type": "birth", "child": child.pub})

    def lineage(self, pub):
        if pub in self.trust_roots:
            return [pub]
        sid = self.births.get(pub)
        if sid is None:
            raise Violation("unanchored-genesis", self.rooms[pub].name if pub in self.rooms else pub[:12])
        parent = next(p for p in self.archive.get(sid)["parties"] if p != pub)
        return [pub] + self.lineage(parent)

    def retire(self, room):
        if any(o["debtor"] == room.pub for o in self._open.values()):
            raise Violation("open-obligations", f"{room.name} still owes")
        room.append("death", {})
        room.dead = True

    # ---- audit

    def audit(self, receipt, head, resolve, now=None, retain_until=None):
        """Does the log ending at head still contain the receipt its owner once signed?"""
        result = ancestry(resolve, head, oid(receipt))
        if result == "refuted":
            raise Violation("undeclared-rewrite", "the log no longer contains an entry its owner signed")
        if result == "unverifiable" and retain_until is not None and now is not None and now <= retain_until:
            raise Violation("retention-failed", "pre-images are missing inside the retention term")
        return result
