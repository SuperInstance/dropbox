"""PROTOTYPE. Every claim from the design conversation, written as an attack the code must survive.

Tests named test_limit_* pin the holes the design does NOT close: they assert the bad thing gets through.
"""
import json

import pytest

from quilt.core import (H, Hb, Clock, Quilt, Registry, Resource, Room, Store, Violation, ancestry, cite,
                        equivocation, gossip, make_entry, merkle_check, merkle_path, merkle_root,
                        oid, order_refutes, propose, sign, trace_back, verify_view)
from quilt.tiers import best_fork, progresses


def world(*names, **kw):
    clock = Clock("clock")
    q = Quilt(clock=clock, **kw)
    rooms = [Room(n) for n in names]
    q.join(clock, *rooms)
    clock.tick()
    return (q, clock, *rooms)


def expect(code, fn):
    with pytest.raises(Violation) as e:
        fn()
    assert e.value.code == code, f"wanted {code}, got {e.value.code}: {e.value.detail}"
    return e.value


def owe(q, debtor, creditor, amount=300, due=10, **kw):
    body = {"type": "obligation", "debtor": debtor.pub, "creditor": creditor.pub,
            "amount": amount, "due": due, "what": "deliver the survey"}
    return q.stitch([debtor, creditor], body, **kw)[0]


def discharge(q, debtor, creditor, ref, amount):
    return q.stitch([debtor, creditor], {"type": "discharge"},
                    cites=[cite(ref, amount=amount, debtor=debtor.pub, creditor=creditor.pub)])


def rewrite(room, entries):
    """A room rebuilding its own log from scratch. It owns its key, so every signature is valid."""
    room.store, room.head, room.seq = Store(), None, 0
    for kind, body in entries:
        room.append(kind, body)


# ---------------------------------------------------------------- records

def test_tampered_entry_is_caught_and_resigning_breaks_the_chain():
    a = Room("alice")
    a.note("one"); a.note("two"); a.note("three")
    view = a.view()
    verify_view(view)

    tampered = json.loads(json.dumps(view))
    tampered[0]["body"]["narrative"] = Hb(b"something else")
    expect("bad-signature", lambda: verify_view(tampered))

    tampered[0] = make_entry(a.key, 0, None, "note", tampered[0]["body"])  # owner re-signs
    expect("broken-chain", lambda: verify_view(tampered))


def test_a_view_cannot_quietly_start_mid_log():
    a = Room("alice")
    a.note("the inconvenient part"); a.note("two"); a.note("three")
    expect("broken-chain", lambda: verify_view(a.view()[1:]))    # truncation is not compaction


def test_forged_and_missing_signatures_rejected():
    q, clock, a, b = world("alice", "bob")
    mallory = Room("mallory")
    s = propose([a, b], {"type": "note"})
    sign(s, a.key)
    expect("incomplete-signatures", lambda: q.admit(s))
    s["sigs"][b.pub] = mallory.key.sign(oid(s))
    expect("bad-signature", lambda: q.admit(s))


def test_stitch_commits_a_private_log_without_revealing_it():
    q, clock, a, b = world("alice", "bob")
    a.note("secret plan: undercut bob")
    sid, receipts = q.stitch([a, b], {"type": "note"})
    stitch = q.archive.get(sid)
    assert "secret" not in json.dumps(stitch) and "secret" not in json.dumps(receipts)

    assert ancestry(a.store.get, a.head, oid(receipts[a.pub])) == "verified"
    rewrite(a, [("note", {"narrative": Hb(b"nothing to see")})])
    assert ancestry(a.store.get, a.head, oid(receipts[a.pub])) == "refuted"


# ---------------------------------------------------------------- compaction

def test_declared_compaction_keeps_the_view_verifiable_and_traceable():
    q, clock, a, b = world("alice", "bob")
    a.note("thinking"); q.stitch([a, b], {"type": "note"}); a.note("more thinking")
    before = len(a.view())
    c = q.compact(a, "talked with bob")

    view = a.view()
    assert len(view) == 1 and view[0]["kind"] == "compact"
    verify_view(view)
    a.note("after"); verify_view(a.view())

    pre = trace_back(c, a.store.get)
    assert len(pre) == before == c["body"]["covers"]


def test_trace_back_is_a_retention_question():
    q, clock, a, b = world("alice", "bob")
    a.note("one"); a.note("two")
    c = q.compact(a, "summary")

    handed_off = a.forget(c)
    assert trace_back(c, a.store.get) is None            # commitment survives, pre-image does not

    retainer = Store()
    for e in handed_off:
        retainer.put(e)
    assert len(trace_back(c, retainer.get)) == 2          # someone else kept it

    handed_off[0]["body"]["narrative"] = Hb(b"swapped")   # retainer returns something else
    bad = Store()
    for e in handed_off:
        bad.put(e, key=oid(e))
    assert trace_back(c, bad.get) is None


def test_undeclared_rewrite_is_caught_by_the_counterparty_copy():
    q, clock, a, b = world("alice", "bob")
    a.note("before")
    sid, receipts = q.stitch([a, b], {"type": "note"})
    alices_receipt = b.seen[(a.pub, receipts[a.pub]["seq"])]   # bob holds alice's signed receipt

    rewrite(a, [("note", {"narrative": Hb(b"before")}), ("note", {"narrative": Hb(b"no stitch here")})])
    verify_view(a.view())                                       # her new log is internally perfect

    expect("undeclared-rewrite", lambda: q.audit(alices_receipt, a.head, a.store.get))
    assert equivocation(alices_receipt, a.view()[1])            # two signed entries, one seq


def test_lapsed_retention_is_unverifiable_and_a_fault_only_within_the_term():
    q, clock, a, b = world("alice", "bob")
    sid, receipts = q.stitch([a, b], {"type": "note"}, retain_until=5)
    a.note("later thought")
    last = a.note("last thought before housekeeping")
    c = q.compact(a, "summary")
    a.forget(c)

    # the entry directly under a compaction stays provable with no pre-images: the compaction names it
    assert q.audit(last, a.head, a.store.get) == "verified"

    receipt = receipts[a.pub]
    expect("retention-failed", lambda: q.audit(receipt, a.head, a.store.get, now=3, retain_until=5))
    assert q.audit(receipt, a.head, a.store.get, now=9, retain_until=5) == "unverifiable"


def test_compaction_carries_open_obligations_whatever_the_summary_says():
    q, clock, a, b = world("alice", "bob")
    debt = owe(q, a, b)
    c = q.compact(a, "nothing outstanding with bob")       # the mind's summary is wrong
    assert debt in c["body"]["carried"]                    # the mechanism's index is not
    assert c["body"]["floor"] == 1


# ---------------------------------------------------------------- the lossy-mind table

def test_forgotten_obligation_is_fired_by_the_clock():
    q, clock, a, b = world("alice", "bob")
    debt = owe(q, a, b, due=4)
    a.mind = {}                                            # compacted away
    assert q.due(clock.n) == []
    for _ in range(3):
        clock.tick()
    assert [sid for sid, o in q.due(clock.n)] == [debt]
    assert q.due(clock.n)[0][1]["debtor"] == a.pub


def test_misremembered_term_is_caught_at_write_and_repaired():
    q, clock, a, b = world("alice", "bob")
    debt = owe(q, a, b, amount=300)
    v = expect("citation-mismatch", lambda: discharge(q, a, b, debt, amount=500))
    assert v.record["amount"] == 300                       # the refusal hands back the record
    discharge(q, a, b, debt, amount=v.record["amount"])
    assert q.obligations() == {}


def test_invented_agreement_is_caught_at_write():
    q, clock, a, b = world("alice", "bob")
    expect("unresolved-citation", lambda: discharge(q, a, b, H("an agreement that never happened"), 300))


def test_schema_stops_citing_around_the_checked_field():
    q, clock, a, b = world("alice", "bob")
    debt = owe(q, a, b, amount=300)
    partial = [cite(debt, debtor=a.pub, creditor=b.pub)]   # cites correctly, omits the amount
    expect("citation-incomplete", lambda: q.stitch([a, b], {"type": "discharge", "paid": 500}, cites=partial))


def test_double_promise_is_refused_by_the_resource_room():
    q, clock, a, b = world("alice", "bob")
    dock = Resource("dock-7")
    q.join(dock)
    q.stitch([a, dock], {"type": "claim", "holder": a.pub})
    expect("double-claim", lambda: q.stitch([b, dock], {"type": "claim", "holder": b.pub}))
    q.stitch([a, dock], {"type": "release"})
    q.stitch([b, dock], {"type": "claim", "holder": b.pub})
    assert dock.holder() == b.pub


def test_lost_preimage_fails_a_challenge_though_the_retainer_says_it_has_it():
    chunks = [f"transcript chunk {i}".encode() for i in range(9)]
    leaves = [Hb(c) for c in chunks]
    root = merkle_root(leaves)                             # all the challenger keeps

    class Retainer:
        def __init__(self, data): self.data = data
        def still_have_it(self): return True               # both say yes
        def prove(self, i): return self.data[i], merkle_path([Hb(c) for c in self.data], i)

    honest = Retainer(chunks)
    lossy = Retainer([c if i != 4 else b"transcript chunk 4 (as I recall)" for i, c in enumerate(chunks)])
    assert honest.still_have_it() and lossy.still_have_it()

    for i in range(9):
        chunk, path = honest.prove(i)
        assert merkle_check(root, Hb(chunk), path)
    chunk, path = lossy.prove(4)
    assert not merkle_check(root, Hb(chunk), path)


def test_limit_unfaithful_narrative_summary_is_not_caught():
    q, clock, a, b = world("alice", "bob")
    a.note("bob mentioned he needs the survey by the 12th, no later")   # narrative only
    c = q.compact(a, "bob said any time this month is fine")
    verify_view(a.view())                                                # signed, chained, wrong
    assert c["body"]["summary"] == Hb(b"bob said any time this month is fine")


def test_limit_uncited_belief_is_not_caught():
    q, clock, a, b, c = world("alice", "bob", "carol")
    owe(q, a, b, amount=300)
    # alice tells carol about the debt in free text, with the wrong figure, citing nothing
    q.stitch([a, c], {"type": "note", "text": "I owe bob 500, can you cover it?"})


# ---------------------------------------------------------------- time

def test_time_is_an_interval_between_two_clock_facts():
    q, clock, a, b = world("alice", "bob")
    sid, _ = q.stitch([a, b], {"type": "note"})
    assert q.interval(sid) == (1, None)          # after tick 1, not yet attested
    clock.tick()
    assert q.interval(sid) == (1, 2)


def test_backdating_is_refuted_only_when_the_pair_is_sandwiched():
    q, clock, a, b, c, d, e = world("alice", "bob", "carol", "dan", "erin")
    old = clock.ref()                            # tick 1, saved for later misuse
    for _ in range(4):
        clock.tick()
    q.stitch([a, c], {"type": "note"})           # third party, after tick 5
    for _ in range(15):
        clock.tick()                             # now tick 20

    # alice and bob collude: "we agreed this at tick 3"
    expect("time-refuted", lambda: q.stitch([a, b], {"type": "note"}, after=old, claimed_time=3))

    # dan and erin collude the same way with no third party between them: nothing refutes it
    sid, _ = q.stitch([d, e], {"type": "note"}, after=old, claimed_time=3)
    clock.tick()
    assert q.interval(sid) == (1, 21)            # the ledger vouches for the interval, not the claim


def test_stale_head_is_refused_so_a_room_cannot_stitch_around_its_own_history():
    q, clock, a, b, c = world("alice", "bob", "carol")
    s = propose([a, b], {"type": "note"}, after=clock.ref())
    sign(s, a.key); sign(s, b.key)
    q.stitch([a, c], {"type": "note"})           # alice's log moves on
    expect("stale-head", lambda: q.admit(s))


def test_sequence_numbers_refute_backdating_after_preimages_are_gone():
    q, clock, a, b, c = world("alice", "bob", "carol")
    for _ in range(4):
        clock.tick()
    s1, r1 = q.stitch([a, c], {"type": "note"})                 # after tick 5; carol keeps alice's receipt
    early = c.seen[(a.pub, r1[a.pub]["seq"])]

    # alice compacts with a false floor and forgets, then backdates with bob
    cmp = a.append("compact", {"covers": 1, "root": merkle_root([a.head]), "summary": Hb(b"x"),
                               "carried": [], "floor": 0})
    a.forget(cmp)
    q2 = Quilt(clock=clock); q2.join(clock, a, b)               # a verifier who never saw carol
    s2, r2 = q2.stitch([a, b], {"type": "note"}, after=None, claimed_time=2)

    assert order_refutes(early, q.archive.get(s1), r2[a.pub], q2.archive.get(s2))


def test_second_signer_holds_a_free_option_unless_the_proposal_expires():
    q, clock, a, b = world("alice", "bob")
    open_ended = propose([a, b], {"type": "obligation", "debtor": a.pub, "creditor": b.pub,
                                  "amount": 300, "due": 50, "what": "x"}, after=clock.ref())
    sign(open_ended, a.key)
    for _ in range(10):
        clock.tick()                             # bob waits to see how things turn out
    sign(open_ended, b.key)
    q.admit(open_ended)                          # and binds alice ten ticks later

    dated = propose([a, b], {"type": "obligation", "debtor": a.pub, "creditor": b.pub,
                             "amount": 300, "due": 50, "what": "y"}, after=clock.ref(),
                    valid_by=clock.n + 2)
    sign(dated, a.key)
    for _ in range(10):
        clock.tick()
    sign(dated, b.key)
    expect("stitch-expired", lambda: q.admit(dated))


def test_a_clock_that_rewrites_a_tick_is_caught_by_anyone_who_cited_it():
    q, clock, a, b = world("alice", "bob")
    clock.tick(); clock.tick()
    sid, _ = q.stitch([a, b], {"type": "note"})
    cited = clock.store.get(q.archive.get(sid)["after"]["id"])

    backdated = make_entry(clock.key, cited["seq"], cited["prev"], "tick",
                           {"n": cited["body"]["n"], "attests": [H("a late arrival")]})
    assert equivocation(cited, backdated)


# ---------------------------------------------------------------- custody

def fork_custodian(q, dock, a, b):
    saved = (dock.head, dock.seq)
    q.stitch([a, dock], {"type": "claim", "holder": a.pub})
    dock.head, dock.seq = saved                  # the custodian shows bob a log without alice in it
    q.stitch([b, dock], {"type": "claim", "holder": b.pub})


def test_custodian_fork_is_proven_when_the_claimants_compare_receipts():
    q, clock, a, b = world("alice", "bob")
    dock = Resource("dock-7"); q.join(dock)
    fork_custodian(q, dock, a, b)
    assert a.alarms == [] and b.alarms == []
    gossip(a, b)
    proof = (a.alarms or b.alarms)[0]
    assert equivocation(*proof) and proof[0]["room"] == dock.pub


def test_custodian_fork_reaches_the_victims_through_a_third_room():
    q, clock, a, b, c = world("alice", "bob", "carol")
    dock = Resource("dock-7"); q.join(dock)
    fork_custodian(q, dock, a, b)
    gossip(a, c)
    assert c.alarms == []
    gossip(c, b)
    assert c.alarms or b.alarms


def test_limit_custodian_fork_is_invisible_to_disconnected_claimants():
    q, clock, a, b, c = world("alice", "bob", "carol")
    dock = Resource("dock-7"); q.join(dock)
    fork_custodian(q, dock, a, b)
    gossip(a, c)                                 # bob never talks to either
    assert a.alarms == b.alarms == c.alarms == []


def test_a_registry_witness_refuses_the_fork_outright():
    q, clock, a, b = world("alice", "bob")
    dock, reg = Resource("dock-7"), Registry("harbour-registry")
    q.join(dock, reg)
    saved = (dock.head, dock.seq)
    q.stitch([a, dock, reg], {"type": "claim", "holder": a.pub})
    dock.head, dock.seq = saved
    expect("fork-refused", lambda: q.stitch([b, dock, reg], {"type": "claim", "holder": b.pub}))


def test_unanimous_signing_prevents_forks_but_one_signer_can_stall():
    for n in (2, 3, 5):
        assert not best_fork(n=n, byzantine=n - 1, mode="unanimous")   # one honest signer is enough
        assert progresses(n=n, stalled=0, mode="unanimous")
        assert not progresses(n=n, stalled=1, mode="unanimous")


def test_quorum_prevents_forks_up_to_f_and_keeps_moving():
    for n, f in ((4, 1), (7, 2)):
        assert not best_fork(n=n, byzantine=f, mode="quorum")
        assert progresses(n=n, stalled=f, mode="quorum")
        assert best_fork(n=n, byzantine=f + 1, mode="quorum")         # and breaks past f


def test_single_custodian_can_always_fork():
    assert best_fork(n=4, byzantine=0, mode="single")


# ---------------------------------------------------------------- lifecycle

def fleet():
    q, clock, op = world("operator")
    q.trust_roots = {op.pub}
    q.require_lineage = True
    return q, clock, op


def test_lineage_traces_to_the_operator_root():
    q, clock, op = fleet()
    a, a1 = Room("alice"), Room("alice-child")
    q.birth(op, a); q.birth(a, a1)
    assert q.lineage(a1.pub) == [a1.pub, a.pub, op.pub]


def test_unanchored_room_is_rejected_inside_the_fleet():
    q, clock, op = fleet()
    a, stranger = Room("alice"), Room("stranger")
    q.birth(op, a); q.join(stranger)
    expect("unanchored-genesis", lambda: q.stitch([a, stranger], {"type": "note"}))


def test_swapping_the_mind_leaves_the_obligations_where_they_were():
    q, clock, a, b = world("alice", "bob")
    debt = owe(q, a, b)
    a.mind = "model-v1"; a.mind = "model-v2"
    assert q.obligations()[debt]["debtor"] == a.pub


def test_a_room_cannot_die_owing_and_novation_needs_the_creditor():
    q, clock, a, b, c = world("alice", "bob", "carol")
    debt = owe(q, a, b)
    expect("open-obligations", lambda: q.retire(a))

    hand_over = {"type": "transfer", "to": c.pub}
    cites = [cite(debt, amount=300, debtor=a.pub, creditor=b.pub)]
    expect("novation-needs-creditor", lambda: q.stitch([a, c], hand_over, cites=cites))
    q.stitch([a, b, c], hand_over, cites=cites)
    assert q.obligations()[debt]["debtor"] == c.pub

    q.retire(a)
    expect("dead-room", lambda: q.stitch([a, b], {"type": "note"}))


def test_a_declared_fork_is_two_births_a_transfer_and_a_death():
    q, clock, op = fleet()
    a, b, a1, a2 = Room("alice"), Room("bob"), Room("alice-1"), Room("alice-2")
    q.birth(op, a); q.birth(op, b)
    debt = owe(q, a, b)
    q.birth(a, a1); q.birth(a, a2)
    q.stitch([a, a1, b], {"type": "transfer", "to": a1.pub},
             cites=[cite(debt, amount=300, debtor=a.pub, creditor=b.pub)])
    q.retire(a)
    assert q.lineage(a2.pub)[1] == a.pub and q.obligations()[debt]["debtor"] == a1.pub


# ---------------------------------------------------------------- retention

def test_citing_an_entry_renews_its_lease_and_everything_it_rests_on():
    q, clock, a, b = world("alice", "bob")
    terms, _ = q.stitch([a, b], {"type": "note", "text": "terms"}, retain_until=5)
    stray, _ = q.stitch([a, b], {"type": "note", "text": "chatter"}, retain_until=5)
    debt = owe(q, a, b, retain_until=5, cites=[cite(terms)])
    q.stitch([a, b], {"type": "note"}, retain_until=100, cites=[cite(debt)])

    q.archive.gc(50)
    assert q.archive.status(debt) == "live" and q.archive.status(terms) == "live"
    assert q.archive.status(stray) == "expired"


def test_expired_and_invented_citations_are_told_apart():
    q, clock, a, b = world("alice", "bob")
    old, _ = q.stitch([a, b], {"type": "note"}, retain_until=5)
    q.archive.gc(50)
    expect("expired-citation", lambda: q.stitch([a, b], {"type": "note"}, cites=[cite(old)]))
    expect("unresolved-citation", lambda: q.stitch([a, b], {"type": "note"}, cites=[cite(H("never"))]))


def test_narrative_can_be_promoted_only_while_its_preimage_survives():
    q, clock, a, b = world("alice", "bob")
    text = "bob mentioned he needs the survey by the 12th"
    n = a.note(text)
    raw = Hb(text.encode())
    promote = lambda: q.stitch([a, b], {"type": "promote", "raw": raw, "fields": {"due": 12}},
                               cites=[cite(oid(n), narrative=raw)])
    promote()

    a.store.drop(raw)                 # the entry survives, so it is provable THAT something was said,
    v = expect("unresolved-citation", promote)          # but no longer WHAT
    assert "narrative" in v.detail

    c = q.compact(a, "summary"); a.forget(c)
    expect("unresolved-citation", promote)
