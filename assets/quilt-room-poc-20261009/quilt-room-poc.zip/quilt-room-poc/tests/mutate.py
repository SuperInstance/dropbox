"""PROTOTYPE. Break each check in turn and confirm some test notices.

A suite that passes on the first run proves little. This removes one guard at a time from
quilt/core.py (in a temp copy), reruns the tests, and reports any guard whose removal goes unnoticed.
Run from the repo root: python3 tests/mutate.py
"""
import pathlib
import shutil
import subprocess
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent.parent

MUTATIONS = [  # (what is being removed, exact source text, replacement)
    ("signature check on entries", 'if not sig_ok(e["room"], oid(e), e.get("sig", "")):\n        raise', 'if False:\n        raise'),
    ("hash link check in a view", 'if i and (e["prev"] != oid(view[i - 1]) or', 'if False and (e["prev"] != oid(view[i - 1]) or'),
    ("mid-log view without compaction", 'if view and view[0]["kind"] != "compact" and view[0]["prev"] is not None:', 'if False:'),
    ("stitch signature check", 'if not sig_ok(p, sid, s["sigs"][p]):', 'if False:'),
    ("every party must sign", 'if p not in s["sigs"]:', 'if False:'),
    ("expired citation", 'if self.archive.status(c["ref"]) == "expired":', 'if False:'),
    ("unresolved citation", 'if obj is None:\n                raise Violation("unresolved-citation"', 'if False:\n                raise Violation("unresolved-citation"'),
    ("citation field match", 'if record.get(k) != v:', 'if False:'),
    ("citation schema", 'if need and not any(', 'if False and not any('),
    ("time claim against history", 'if s["claimed_time"] is not None and s["claimed_time"] < self.lower_bound(s):', 'if False:'),
    ("history in the time floor", 'return max([own] + [self.floor_of(p, h) for p, h in s["heads"].items()])', 'return own'),
    ("stale head", 'if s["heads"][r.pub] != r.head:', 'if False:'),
    ("proposal expiry", 'if s["valid_by"] is not None and self.clock.n > s["valid_by"]:', 'if False:'),
    ("dead room", 'if r.dead:', 'if False:'),
    ("lineage", 'if p != newborn:\n                    self.lineage(p)', 'if p != newborn:\n                    pass'),
    ("resource rule", 'if stitch["body"].get("type") == "claim" and self.holder() is not None:', 'if False:'),
    ("novation needs creditor", 'if ob["creditor"] not in s["parties"]:', 'if False:'),
    ("death with open debts", 'if any(o["debtor"] == room.pub for o in self._open.values()):', 'if False:'),
    ("undeclared rewrite", 'if result == "refuted":', 'if False:'),
    ("retention inside term", 'if result == "unverifiable" and retain_until is not None', 'if False and retain_until is not None'),
    ("equivocation alarm", 'if have is not None and oid(have) != oid(entry):', 'if False:'),
    ("lease renewal by citation", 'self.archive.extend(c["ref"], until)', 'pass'),
    ("lease renewal through closure", 'self._renew(cited, until)', 'pass'),
    ("mechanism-carried obligations", 'carried = [sid for sid, o in self._open.items() if room.pub in (o["debtor"], o["creditor"])]', 'carried = []'),
    ("promotion needs the raw text", 'if t == "promote" and self.resolve(s["body"]["raw"]) is None:', 'if False:'),
    ("registry refuses a second successor", 'if pub != self.pub and self.successor.setdefault((pub, head), sid) != sid:', 'if False:'),
    ("merkle path check", 'return h == root', 'return True'),
    ("honest signer signs once per seq", 'if self.signed.setdefault(step["seq"], sid) != sid:', 'if False:'),
]


def run(tmp):
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-x", "tests/test_attacks.py"],
                       cwd=tmp, capture_output=True, text=True)
    return r.returncode != 0


def main():
    survivors = []
    for what, old, new in MUTATIONS:
        with tempfile.TemporaryDirectory() as tmp:
            for d in ("quilt", "tests"):
                shutil.copytree(ROOT / d, pathlib.Path(tmp) / d, ignore=shutil.ignore_patterns("__pycache__"))
            hit = False
            for f in ("quilt/core.py", "quilt/tiers.py"):
                p = pathlib.Path(tmp) / f
                src = p.read_text()
                if old in src:
                    p.write_text(src.replace(old, new, 1))
                    hit = True
                    break
            if not hit:
                print(f"NOT FOUND  {what}")
                survivors.append(what)
                continue
            caught = run(tmp)
            print(f"{'caught   ' if caught else 'SURVIVED '} {what}")
            if not caught:
                survivors.append(what)
    print(f"\n{len(MUTATIONS) - len(survivors)} of {len(MUTATIONS)} removed guards were noticed by the tests")
    return 1 if survivors else 0


if __name__ == "__main__":
    sys.exit(main())
