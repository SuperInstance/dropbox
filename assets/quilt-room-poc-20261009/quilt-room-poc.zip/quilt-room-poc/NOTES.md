# What the prototype answered

**Question.** Do rooms, stitches, custodians and one citation rule hold together when run, for agents
that are honest but lossy?

**Short answer.** Yes for everything a mechanism can check, and building it corrected the design in
eleven places. The holes it leaves open are the ones predicted, and they are pinned by tests so they
cannot be forgotten.

Status of the evidence: 38 attack tests pass, and removing any of 28 guards makes a test fail. Two
simulations ran on fixed seeds. Nothing here involved a real language model, a network or more than
one process.

## What building it changed

1. **The retention challenge I proposed was wrong.** "Hash of the pre-image with a fresh nonce" can
   only be checked by someone who still holds the pre-image. What works is committing a Merkle root
   and asking for one random chunk with its path. A lossy retainer that says "yes, I still have it"
   then fails the check (`test_lost_preimage_fails_a_challenge…`).
2. **The last signer of a stitch holds a free option.** Once alice has signed, bob can wait to see
   how things turn out and bind her later. Proposals need an expiry tick, which makes the clock room
   part of co-signing, not an extra (`test_second_signer_holds_a_free_option…`).
3. **The stale-head rule carries the time sandwich.** A stitch must commit to each party's actual
   current head, or a room can stitch around its own history and backdate. The cost is that a room
   can have only one stitch in flight at a time. Concurrency against tight commitment is a real
   tension the conversation did not see.
4. **Sequence numbers do sandwich duty after the pre-images are gone.** Two signed receipts from the
   same room, with their order, refute a backdated claim with no log at all
   (`test_sequence_numbers_refute_backdating…`). They are also what makes an equivocation proof
   self-contained.
5. **The entry directly under a compaction stays provable forever.** The compaction names it by hash,
   so no pre-image is needed. Retention only matters from the second entry down.
6. **Compaction has to carry more than obligations.** It must also carry the room's time floor, or
   forgetting pre-images becomes a way to backdate. The mechanism writes both; the mind writes only
   the summary.
7. **Citation needs a schema per commitment type.** Without one, a mind can cite the right record and
   state the wrong figure beside it, unchecked (`test_schema_stops_citing_around_the_checked_field`).
8. **Expired and never-existed must be told apart.** A tombstone per expired entry costs almost
   nothing and turns "unresolved" into two different answers.
9. **A hash proves that something was said, not what.** A note's log entry can outlive its text.
   Promotion of narrative to a structured field needs the text, not just the entry.
10. **Stitches are not always pairwise.** Handing a debt to another room needs the creditor's
    signature, so it is a three-party stitch. "The ledger is the union of pairwise ledgers" should
    read "of co-signed stitches". A declared fork then needs no primitive of its own: it is two
    births, a transfer and a death.
11. **Lineage is itself a retention question.** Tracing a room to the operator's root walks birth
    stitches, so those must be kept forever.

## What the simulations showed

**Custodian fork detection** (`results/fork.md`, 2,000 forks per row).

- In a connected fleet every fork was caught: 0 of 50,000 went undetected.
- It is not fast. 100 rooms stitching once every two rounds: median 6 rounds, 99th percentile 14.
- Stitch rate sets the delay. Twenty times fewer stitches takes about 15 times longer; a fleet 100
  times larger takes about twice as long.
- Exposure follows the victims' own stitch rate. Victims at one hundredth of the fleet's rate: mean
  299 rounds.
- A seam between two orgs can be thin (1% of stitches crossing adds 5 rounds) but not absent (none
  crossing: never caught).
- Uneven activity stretches the tail more than the middle. With log-normal stitch rates (sigma
  1.5) and random victims: median 11 rounds and 99th percentile 257, against 6 and 14 in an even
  fleet.
- One agreed witness room per custodian catches every fork immediately for one message per claim.
  Random witnesses need about the square root of the fleet size each to get to two in three.
- In a fleet of 1,000, 87% of forks are found by two rooms that are neither victim.

The design consequence is in the code as `Registry`: with a witness as a third party to each claim,
the fork is refused outright (`test_a_registry_witness_refuses_the_fork_outright`).

**Honest-but-lossy fleet** (`results/fleet.md`, 3,424 debts, assumed fault rates of 8% each for
forgetting, wrong amount and wrong due date).

| Regime | On time, right amount | Wrong amount on the ledger | Missed | Blocked | Invented debts paid |
| --- | --- | --- | --- | --- | --- |
| Memory only | 80.2% | 8.1% | 8.0% | 0% | 106 of 110 |
| Counterparty checks, independent errors | 79.7% | 1.4% | 0.7% | 14.6% | 106 of 110 |
| Counterparty checks, fully shared errors | 80.2% | 8.1% | 8.0% | 0% | 106 of 110 |
| Citation check | 88.3% | 0% | 8.0% | 0% | 0 of 110 |
| Citation check and clock | 100% | 0% | 0% | 0% | 0 of 110 |

- **A second lossy memory changes how things fail, not how often they go right.** With equal fault
  rates on both sides, counterparty checking cut wrong amounts and misses by about five sixths and
  blocked 14.6% of debts in disagreements neither side could settle. The success rate did not move.
- **Shared errors erase the benefit entirely.** When both minds lose the same detail, the
  counterparty row is identical to memory only.
- **A write-time check cannot fix a misremembered "when".** The citation regime still left 3.7% late
  and 8.0% missed. Only the clock catches those.
- The last row is 100% by construction: the mechanism is perfect in this model. Its information is
  that the whole path ran through real code, about 1,100 stitches and 450 compactions per run, with
  every log verifying at the end.

## Holes still open, pinned by tests

- An unfaithful narrative summary is signed, chained and wrong (`test_limit_unfaithful_narrative…`).
- A belief stated in free text, citing nothing, passes (`test_limit_uncited_belief…`).
- A fork between claimants who never connect is invisible (`test_limit_custodian_fork_is_invisible…`).
- Nothing checks whether a correctly recorded commitment was a good idea.

## Not built

Networking, concurrency, real minds, a real consensus protocol, cross-org archives, key storage, a
DAG-ordered fold (obligations are folded in admission order), and limits on how many receipts a room
carries when it gossips.

## Verdict

Keep the model: rooms, n-party stitches, mechanism rooms, citation with schemas, declared compaction
that carries obligations and a time floor, a clock room with proposal expiry, and a witness per
custodian. Throw the code away.
