"""PROTOTYPE. How long does a forking custodian go unnoticed?

A custodian (a Resource room) shows two claimants two different logs. Each claimant holds a
receipt the custodian signed. The fork is proven the moment any one room holds both receipts.
Rooms only learn receipts by stitching with each other, so detection depends on how the quilt
is connected.

What is real here: the rooms, keys, the forked claim stitches, the receipts, the signature
checks, and the equivocation proof. What is modelled: who stitches with whom, as random
pairings at a set rate. A stitch between two ordinary rooms is reduced to the receipt exchange
it carries, because nothing else about it affects detection.

Run from the repo root:  python3 -m experiments.fork            (full run, a few minutes)
                         python3 -m experiments.fork --quick    (about a tenth of the trials)
"""
from __future__ import annotations

import json
import math
import pathlib
import random
import statistics
import sys
import time
from concurrent.futures import ProcessPoolExecutor

from quilt.core import Quilt, Resource, Room, equivocation, gossip

OUT = pathlib.Path(__file__).resolve().parent.parent / "results"
CLAIM = lambda who: {"type": "claim", "holder": who.pub}


def poisson(rng, mean):
    n, t = 0, rng.expovariate(1.0)
    while t < mean:
        n += 1
        t += rng.expovariate(1.0)
    return n


def fork(dock, a, b):
    """The real thing: two co-signed claim stitches on two branches of one custodian log."""
    q = Quilt()
    q.join(dock, a, b)
    saved = (dock.head, dock.seq)
    q.stitch([a, dock], CLAIM(a))
    dock.head, dock.seq = saved
    q.stitch([b, dock], CLAIM(b))


def trial(rng, rooms, lam, horizon, tag, orgs=None, cross=0.0, witnesses=0, registry=False, quiet=1.0,
          activity=None, pick="random"):
    """One fork. Returns (rounds until some room holds both receipts, who found it) or (None, None).

    lam        mean stitches a room takes part in per round
    orgs       None, or (list_a, list_b) index lists: victims are placed one in each
    cross      fraction of stitches that join the two orgs
    witnesses  each victim pushes its receipt to this many random rooms straight away
    registry   both victims push to one agreed room per custodian instead
    quiet      victims stitch at this multiple of everyone else's rate
    activity   per-room stitch-rate multipliers (mean 1) for an uneven fleet
    pick       with activity: "random" victims, or the two "quietest" rooms
    """
    n = len(rooms)
    if orgs:
        ia, ib = rng.choice(orgs[0]), rng.choice(orgs[1])
    elif activity and pick == "quietest":
        ia, ib = sorted(range(n), key=activity.__getitem__)[:2]
    else:
        ia, ib = rng.sample(range(n), 2)
    a, b = rooms[ia], rooms[ib]
    touched = {ia, ib}
    for r in (a, b):
        r.seen, r.alarms = {}, []
    fork(Resource(f"dock-{tag}"), a, b)

    def meet(i, j):
        x, y = rooms[i], rooms[j]
        if not x.seen and not y.seen:
            return None
        touched.add(i); touched.add(j)
        proof = gossip(x, y)
        if proof and equivocation(*proof):
            return "victim" if x is a or x is b or y is a or y is b else "bystanders"
        return None

    def finish(result):
        for i in touched:
            rooms[i].seen, rooms[i].alarms = {}, []
        return result

    others = [i for i in range(n) if i not in (ia, ib)]
    if registry:
        w = rng.choice(others)
        for v in (ia, ib):
            if (who := meet(v, w)):
                return finish((0, who))
    for v in (ia, ib):
        for w in rng.sample(others, min(witnesses, len(others))):
            if (who := meet(v, w)):
                return finish((0, who))

    weights = list(activity) if activity else None
    if quiet != 1.0:
        weights = [quiet if i in (ia, ib) else 1.0 for i in range(n)]
    total_w = sum(weights) if weights else n
    idx = range(n)

    for rnd in range(1, horizon + 1):
        for _ in range(poisson(rng, total_w * lam / 2)):
            if orgs:
                if rng.random() < cross:
                    i, j = rng.choice(orgs[0]), rng.choice(orgs[1])
                else:
                    side = orgs[0] if rng.random() < len(orgs[0]) / n else orgs[1]
                    i, j = rng.sample(side, 2)
            elif weights:
                i, j = rng.choices(idx, weights, k=2)
                if i == j:
                    continue
            else:
                i = rng.randrange(n)
                j = rng.randrange(n - 1)
                j += j >= i
            if (who := meet(i, j)):
                return finish((rnd, who))
    return finish((None, None))


def run(label, seed, trials, n, lam, horizon=400, **kw):
    rng = random.Random(seed)
    rooms = [Room(f"room-{i}") for i in range(n)]
    orgs = (list(range(n // 2)), list(range(n // 2, n))) if kw.pop("two_orgs", False) else None
    lumpy = kw.pop("lumpy", None)
    extra = {}
    if lumpy:
        # log-normal activity, scaled so the fleet's mean stitch rate is still lam
        gen = random.Random(seed * 7919 + 1)
        raw = [gen.lognormvariate(0, lumpy) for _ in range(n)]
        kw["activity"] = [x * n / sum(raw) for x in raw]
        ranked = sorted(kw["activity"])
        extra = {"lumpy": lumpy, "quietest_rate": round(lam * ranked[0], 4),
                 "median_rate": round(lam * ranked[n // 2], 4), "busiest_rate": round(lam * ranked[-1], 2)}
    times, finders = [], {"victim": 0, "bystanders": 0}
    for t in range(trials):
        rnd, who = trial(rng, rooms, lam, horizon, f"{label}-{seed}-{t}", orgs=orgs, **kw)
        if rnd is not None:
            times.append(rnd)
            finders[who] += 1
    times.sort()
    found = len(times)
    pct = lambda p: times[min(found - 1, int(p * found))] if found else None
    within = lambda d: round(sum(1 for x in times if x <= d) / trials, 4)
    return {
        "label": label, "n": n, "stitch_rate": lam, "trials": trials, "horizon": horizon,
        **{k: v for k, v in kw.items() if k != "activity"}, **extra,
        "two_orgs": bool(orgs),
        "undetected": round(1 - found / trials, 4),
        "mean": round(statistics.fmean(times), 2) if found else None,
        "median": pct(0.5), "p90": pct(0.9), "p99": pct(0.99),
        "within_0": within(0), "within_1": within(1), "within_2": within(2),
        "within_5": within(5), "within_10": within(10),
        "found_by_bystanders": round(finders["bystanders"] / found, 3) if found else None,
        "predicted_mean": round(math.log(2 * n) / (2 * lam), 2),
    }


def table(rows, cols):
    head = "| " + " | ".join(h for h, _ in cols) + " |"
    rule = "|" + "|".join(" --- " for _ in cols) + "|"
    body = ["| " + " | ".join("" if (v := f(r)) is None else str(v) for _, f in cols) + " |" for r in rows]
    return "\n".join([head, rule] + body)


def pc(x):
    return None if x is None else f"{100 * x:.1f}%"


def _job(args):
    label, seed, trials, n, lam, kw = args
    return run(label, seed, trials, n, lam, **kw)


def main(quick=False):
    T = 200 if quick else 2000
    t0 = time.time()
    out = {"trials_per_row": T, "quick": quick}

    jobs = []
    # 1. Baseline: one well-mixed fleet. How long, by fleet size and stitch rate?
    jobs += [("baseline", T, n, lam, {}) for n in (10, 30, 100, 300, 1000) for lam in (0.1, 0.25, 0.5, 1.0, 2.0)]
    # 2. Witnesses: each victim sends its receipt to k random rooms the moment it gets one.
    jobs += [("witnesses", T, 100, 0.5, {"witnesses": k}) for k in (0, 1, 2, 5, 10, 20, 50)]
    jobs += [("witnesses", T, 100, 0.5, {"registry": True})]
    # 3. Two orgs, victims on opposite sides. How thin can the seam be?
    jobs += [("seam", T, 100, 0.5, {"horizon": 20000, "two_orgs": True, "cross": x})
             for x in (0.5, 0.1, 0.01, 0.001, 0.0001)]
    jobs += [("seam", max(20, T // 20), 100, 0.5, {"horizon": 20000, "two_orgs": True, "cross": 0.0})]
    # 4. Quiet victims in a busy fleet.
    jobs += [("quiet", T, 100, 0.5, {"horizon": 20000, "quiet": q}) for q in (1.0, 0.2, 0.05, 0.01)]

    # 5. An uneven fleet: a few busy rooms, many quiet ones. Appended last so earlier rows keep their seeds.
    jobs += [("lumpy", T, 100, 0.5, {"horizon": 20000, "lumpy": s, "pick": p})
             for s in (1.0, 1.5) for p in ("random", "quietest")]

    # every row has its own fixed seed, so results do not depend on how many workers run them
    jobs = [(label, 1000 + i, trials, n, lam, kw) for i, (label, trials, n, lam, kw) in enumerate(jobs)]
    with ProcessPoolExecutor() as pool:
        rows = list(pool.map(_job, jobs))
    for name in ("baseline", "witnesses", "seam", "quiet", "lumpy"):
        out[name] = [r for r in rows if r["label"] == name]
    base, wit, seam, quiet, lumpy = out["baseline"], out["witnesses"], out["seam"], out["quiet"], out["lumpy"]

    out["seconds"] = round(time.time() - t0, 1)
    OUT.mkdir(exist_ok=True)
    name = "fork-quick" if quick else "fork"
    (OUT / f"{name}.json").write_text(json.dumps(out, indent=1))

    md = [f"# Custodian fork detection: raw results\n\n{T} forks per row. Time is in rounds; the stitch rate is the "
          "mean number of stitches a room takes part in per round. Generated by `python3 -m experiments.fork"
          + (" --quick" if quick else "") + "`.\n"]
    md += ["## 1. One well-mixed fleet\n", table(base, [
        ("Rooms", lambda r: r["n"]), ("Stitch rate", lambda r: r["stitch_rate"]),
        ("Mean", lambda r: r["mean"]), ("ln(2N)/2λ", lambda r: r["predicted_mean"]),
        ("Median", lambda r: r["median"]), ("90th pct", lambda r: r["p90"]), ("99th pct", lambda r: r["p99"]),
        ("Caught in 1 round", lambda r: pc(r["within_1"])), ("In 5", lambda r: pc(r["within_5"])),
        ("In 10", lambda r: pc(r["within_10"])), ("Found by two bystanders", lambda r: pc(r["found_by_bystanders"])),
        ("Never (400 rounds)", lambda r: pc(r["undetected"]))])]
    md += ["\n## 2. Witnesses (100 rooms, stitch rate 0.5)\n", table(wit, [
        ("Receipt sent to", lambda r: "one agreed registry room" if r.get("registry") else f"{r['witnesses']} random rooms"),
        ("Caught immediately", lambda r: pc(r["within_0"])), ("Mean", lambda r: r["mean"]),
        ("Median", lambda r: r["median"]), ("90th pct", lambda r: r["p90"])])]
    md += ["\n## 3. Two orgs of 50, victims on opposite sides (stitch rate 0.5)\n", table(seam, [
        ("Share of stitches crossing", lambda r: f"{100 * r['cross']:g}%"), ("Trials", lambda r: r["trials"]),
        ("Mean", lambda r: r["mean"]), ("Median", lambda r: r["median"]), ("90th pct", lambda r: r["p90"]),
        ("Never (20,000 rounds)", lambda r: pc(r["undetected"]))])]
    md += ["\n## 4. Quiet victims (100 rooms, everyone else at stitch rate 0.5)\n", table(quiet, [
        ("Victims' stitch rate", lambda r: round(r["quiet"] * r["stitch_rate"], 4)),
        ("Mean", lambda r: r["mean"]), ("Median", lambda r: r["median"]), ("90th pct", lambda r: r["p90"]),
        ("99th pct", lambda r: r["p99"])])]
    md += ["\n## 5. An uneven fleet (100 rooms, mean stitch rate 0.5, log-normal activity)\n", table(lumpy, [
        ("Spread (sigma)", lambda r: r["lumpy"]), ("Victims", lambda r: "two quietest rooms" if r["pick"] == "quietest" else "random"),
        ("Quietest room's rate", lambda r: r["quietest_rate"]), ("Median room's rate", lambda r: r["median_rate"]),
        ("Busiest room's rate", lambda r: r["busiest_rate"]),
        ("Mean", lambda r: r["mean"]), ("Median", lambda r: r["median"]), ("90th pct", lambda r: r["p90"]),
        ("99th pct", lambda r: r["p99"]), ("Never (20,000 rounds)", lambda r: pc(r["undetected"]))])]
    text = "\n".join(md) + f"\n\nRun time: {out['seconds']} s.\n"
    (OUT / f"{name}.md").write_text(text)
    print(text)


if __name__ == "__main__":
    main(quick="--quick" in sys.argv)
