"""PROTOTYPE. An honest-but-lossy fleet under four memory regimes.

Rooms make real obligations to each other (co-signed stitches), compact their logs on a schedule,
and try to settle each debt when they believe it is due. The minds are honest. Their only fault
is housekeeping: at compaction a mind may forget a debt, misremember its amount, misremember its
due date, or acquire a memory of a debt that never existed.

What is real: keys, logs, stitches, compaction entries, the clock, the citation checker, the
obligation index. What is assumed: the fault rates below. They are invented numbers, so read the
output as "how each regime behaves under the same faults", not as a forecast for real agents.

Regimes
  memory        the mind's memory is the record. Settlements are free text and cite nothing.
  counterparty  as above, plus the creditor (another lossy mind) confirms amounts and sends reminders.
  citation      settlements are typed and must cite the obligation; a mechanism checks the citation.
  citation+clock  as above, plus the obligation index hands the record to the debtor before the due tick.

Run from the repo root:  python3 -m experiments.fleet
"""
from __future__ import annotations

import json
import pathlib
import random
import time

from quilt.core import H, Clock, Quilt, Room, Violation, cite, trace_back, verify_view

OUT = pathlib.Path(__file__).resolve().parent.parent / "results"

ROOMS, TICKS, COMPACT_EVERY, SETTLE_MARGIN = 12, 300, 8, 60
P_FORGET, P_AMOUNT, P_DUE, P_INVENT = 0.08, 0.08, 0.08, 0.03


def draw_fault(rng, amount, due):
    """What one compaction does to one mind's memory of one debt."""
    x = rng.random()
    if x < P_FORGET:
        return ("forget",)
    if x < P_FORGET + P_AMOUNT:
        return ("amount", amount + rng.choice([-1, 1]) * rng.randrange(10, 200))
    if x < P_FORGET + P_AMOUNT + P_DUE:
        return ("due", due + rng.choice([-1, 1]) * rng.randrange(8, 30))
    return ("none",)


def apply(mem, fault):
    if fault[0] == "forget":
        return None
    out = dict(mem)
    if fault[0] in ("amount", "due"):
        out[fault[0]] = fault[1]
    return out


def simulate(regime, rho, seed):
    world = random.Random(seed)                      # the same debts and the same faults in every regime
    clock = Clock(f"clock-{seed}")
    q = Quilt(clock=clock)
    rooms = [Room(f"room-{i}-{seed}") for i in range(ROOMS)]
    q.join(clock, *rooms)
    clock.tick()
    by_pub = {r.pub: r for r in rooms}

    truth = {}        # sid -> {"debtor","creditor","amount","due","faults":{role: fault}}
    mind = {r.pub: {} for r in rooms}                # pub -> sid -> {"role","amount","due","other"}
    pending = {r.pub: [] for r in rooms}             # faults waiting for that room's next compaction
    invented, outcome, settled_at = {}, {}, {}
    refusals = {"citation-mismatch": 0, "unresolved-citation": 0}
    handed_back = 0

    def settle(sid, debtor, creditor, amount, typed):
        """Returns the amount that reached the ledger, or raises Violation."""
        if typed:
            q.stitch([debtor, creditor], {"type": "discharge"},
                     cites=[cite(sid, amount=amount, debtor=debtor.pub, creditor=creditor.pub)])
        else:
            q.stitch([debtor, creditor], {"type": "note", "text": f"settling {sid[:8]} for {amount}"})
        return amount

    def record(sid, amount, now):
        t = truth.get(sid)
        if t is None:
            invented[sid] = "paid"
            return
        settled_at[sid] = now
        outcome[sid] = "wrong amount" if amount != t["amount"] else "late" if now > t["due"] else "on time"

    for now in range(2, TICKS + 1):
        clock.tick()

        # new debts
        for _ in range(world.choice([1, 2, 2, 3])):
            d, c = world.sample(rooms, 2)
            amount, due = world.randrange(100, 1000), now + world.randrange(10, 40)
            sid, _ = q.stitch([d, c], {"type": "obligation", "debtor": d.pub, "creditor": c.pub,
                                       "amount": amount, "due": due, "what": "deliver"})
            fd = draw_fault(world, amount, due)
            fc = draw_fault(world, amount, due)
            if world.random() < rho:
                fc = fd                              # the same summariser loses the same detail
            truth[sid] = {"debtor": d.pub, "creditor": c.pub, "amount": amount, "due": due}
            mind[d.pub][sid] = {"role": "debtor", "amount": amount, "due": due, "other": c.pub}
            mind[c.pub][sid] = {"role": "creditor", "amount": amount, "due": due, "other": d.pub}
            pending[d.pub].append((sid, fd))
            pending[c.pub].append((sid, fc))

        # housekeeping: real compaction entries, and the faults land on the minds
        for i, r in enumerate(rooms):
            if (now + i) % COMPACT_EVERY == 0:
                q.compact(r, f"summary at tick {now}")
                for sid, fault in pending[r.pub]:
                    if sid in mind[r.pub]:
                        after = apply(mind[r.pub][sid], fault)
                        if after is None:
                            del mind[r.pub][sid]
                        else:
                            mind[r.pub][sid] = after
                pending[r.pub] = []
                if world.random() < P_INVENT:
                    other = world.choice([x for x in rooms if x is not r])
                    fake = H(["invented", r.pub, now])
                    mind[r.pub][fake] = {"role": "debtor", "amount": world.randrange(100, 1000),
                                         "due": now + world.randrange(5, 15), "other": other.pub}
                    invented[fake] = "believed"

        # the clock fires: the index, not the mind, knows what is coming due
        if regime == "citation+clock":
            for sid, o in q.due(now + 2):
                m = mind[o["debtor"]].get(sid)
                if m is None or m["amount"] != o["amount"] or m["due"] != o["due"]:
                    handed_back += 1
                mind[o["debtor"]][sid] = {"role": "debtor", "amount": o["amount"], "due": o["due"],
                                          "other": o["creditor"]}

        # counterparty reminders: a creditor that still remembers chases a debtor that forgot
        if regime == "counterparty":
            for r in rooms:
                for sid, m in list(mind[r.pub].items()):
                    if m["role"] == "creditor" and m["due"] - 1 <= now and sid not in outcome:
                        debtor_mind = mind[m["other"]]
                        if sid not in debtor_mind:
                            debtor_mind[sid] = {"role": "debtor", "amount": m["amount"], "due": m["due"],
                                                "other": r.pub}

        # minds act on what they believe
        for r in rooms:
            for sid, m in list(mind[r.pub].items()):
                if m["role"] != "debtor" or m["due"] - 1 > now or sid in outcome or invented.get(sid) in ("paid", "refused"):
                    continue
                creditor = by_pub[m["other"]]
                if regime == "memory":
                    record(sid, settle(sid, r, creditor, m["amount"], typed=False), now)
                elif regime == "counterparty":
                    theirs = mind[creditor.pub].get(sid)
                    if theirs is not None and theirs["amount"] != m["amount"]:
                        outcome[sid] = "blocked"      # two memories disagree and neither has the record
                    else:
                        record(sid, settle(sid, r, creditor, m["amount"], typed=False), now)
                else:
                    try:
                        record(sid, settle(sid, r, creditor, m["amount"], typed=True), now)
                    except Violation as v:
                        refusals[v.code] += 1
                        if v.code == "unresolved-citation":
                            del mind[r.pub][sid]
                            invented[sid] = "refused"
                        else:                        # the refusal carries the record: repair and retry
                            m["amount"] = v.record["amount"]
                            record(sid, settle(sid, r, creditor, m["amount"], typed=True), now)

    # everything the fleet wrote must still verify, including through every compaction
    compactions = 0
    for r in rooms:
        verify_view(r.view())
        cur = r.store.get(r.head)
        while cur is not None:
            if cur["kind"] == "compact":
                assert trace_back(cur, r.store.get) is not None
                compactions += 1
            cur = r.store.get(cur["prev"]) if cur["prev"] else None
    assert q.obligations() == q._open

    judged = [sid for sid, t in truth.items() if t["due"] <= TICKS - SETTLE_MARGIN]
    tally = {k: 0 for k in ("on time", "late", "wrong amount", "missed", "blocked")}
    for sid in judged:
        tally[outcome.get(sid, "missed")] += 1
    return {"debts": len(judged), **tally,
            "invented": len(invented), "invented_paid": sum(1 for v in invented.values() if v == "paid"),
            "refused_mismatch": refusals["citation-mismatch"], "refused_unresolved": refusals["unresolved-citation"],
            "handed_back": handed_back, "stitches": len(q.order), "compactions": compactions}


def main():
    t0 = time.time()
    seeds = range(8)
    plan = [("memory", 0.0), ("counterparty", 0.0), ("counterparty", 0.5), ("counterparty", 1.0),
            ("citation", 0.0), ("citation+clock", 0.0)]
    rows = []
    for regime, rho in plan:
        runs = [simulate(regime, rho, s) for s in seeds]
        total = {k: sum(r[k] for r in runs) for k in runs[0]}
        rows.append({"regime": regime, "rho": rho, **total})
        print(regime, rho, total, flush=True)

    pct = lambda r, k: f"{100 * r[k] / r['debts']:.1f}%"
    label = lambda r: r["regime"] if r["regime"] != "counterparty" else f"counterparty, {int(100 * r['rho'])}% shared errors"
    lines = ["# Honest-but-lossy fleet: raw results\n",
             f"{ROOMS} rooms, {TICKS} ticks, {len(seeds)} seeds, the same debts and faults in every regime. "
             f"Assumed fault rates per mind per debt: forget {P_FORGET:.0%}, wrong amount {P_AMOUNT:.0%}, "
             f"wrong due date {P_DUE:.0%}; invented debt {P_INVENT:.0%} per compaction. "
             "Generated by `python3 -m experiments.fleet`.\n",
             "| Regime | Debts | On time, right amount | Late | Wrong amount on the ledger | Missed | Blocked | Invented debts paid |",
             "| --- | --- | --- | --- | --- | --- | --- | --- |"]
    for r in rows:
        lines.append(f"| {label(r)} | {r['debts']} | {pct(r, 'on time')} | {pct(r, 'late')} | {pct(r, 'wrong amount')} | "
                     f"{pct(r, 'missed')} | {pct(r, 'blocked')} | {r['invented_paid']} of {r['invented']} |")
    c, k = rows[4], rows[5]
    lines += ["",
              f"Citation regime: the checker refused {c['refused_mismatch']} settlements for a wrong amount (all repaired "
              f"from the record and retried) and {c['refused_unresolved']} for citing a debt that never existed.",
              f"Citation+clock regime: the index handed the record back to a debtor whose memory was missing or wrong "
              f"{k['handed_back']} times.",
              f"Each run wrote about {rows[0]['stitches'] // len(seeds)} stitches and {rows[0]['compactions'] // len(seeds)} "
              "compaction entries; every room's log verified at the end, through every compaction.",
              f"\nRun time: {time.time() - t0:.0f} s."]
    OUT.mkdir(exist_ok=True)
    (OUT / "fleet.json").write_text(json.dumps(rows, indent=1))
    (OUT / "fleet.md").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
