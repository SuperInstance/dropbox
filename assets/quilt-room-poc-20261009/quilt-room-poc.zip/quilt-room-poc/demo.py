"""PROTOTYPE. One walk through the whole protocol, printing what each mechanism says.

Run from the repo root:  python3 demo.py
"""
from quilt.core import (H, Clock, Quilt, Resource, Room, Violation, cite, equivocation, gossip, oid,
                        trace_back, verify_view)


def say(title):
    print(f"\n== {title}")


def attempt(what, fn):
    try:
        out = fn()
        print(f"   accepted   {what}")
        return out
    except Violation as v:
        print(f"   REFUSED    {what}\n              -> {v}")
        return v


def state(q, clock, *rooms):
    debts = ", ".join(f"{q.rooms[o['debtor']].name} owes {q.rooms[o['creditor']].name} {o['amount']} by tick {o['due']}"
                      for o in q.obligations().values()) or "none"
    logs = ", ".join(f"{r.name}: {r.seq} entries, view {len(r.view())}" for r in rooms)
    print(f"   [tick {clock.n}] open debts: {debts}\n   [logs] {logs}")


clock = Clock("clock")
operator, alice, bob, carol = Room("operator"), Room("alice"), Room("bob"), Room("carol")
q = Quilt(clock=clock, trust_roots={operator.pub}, require_lineage=True)
q.join(clock, operator)
clock.tick()
first_tick = clock.ref()          # kept, to be misused later

say("Birth: every room traces to the operator's root")
for r in (alice, bob, carol):
    q.birth(operator, r)
print("   lineage of alice:", " <- ".join(q.rooms[p].name for p in q.lineage(alice.pub)))
attempt("a stranger with no lineage stitches with alice",
        lambda: (q.join(s := Room("stranger")), q.stitch([alice, s], {"type": "note"})))

say("A stitch: alice owes bob 300 by tick 12")
alice.note("private: I think I can deliver early")
debt, receipts = q.stitch([alice, bob], {"type": "obligation", "debtor": alice.pub, "creditor": bob.pub,
                                         "amount": 300, "due": 12, "what": "deliver the survey"})
clock.tick()
print(f"   stitch {debt[:12]} commits to both log heads and reveals neither log")
print(f"   provable time: after tick {q.interval(debt)[0]}, by tick {q.interval(debt)[1]}")
state(q, clock, alice, bob)

say("Housekeeping: alice compacts, and her summary is wrong")
c = q.compact(alice, "nothing outstanding with bob")
verify_view(alice.view())
print(f"   her view is now {len(alice.view())} entry and still verifies")
print(f"   the mechanism carried {len(c['body']['carried'])} open debt past the summary: {c['body']['carried'][0][:12]}")
print(f"   pre-images still on disk: trace-back returns {len(trace_back(c, alice.store.get))} entries")

say("The lossy mind acts on what it remembers")
v = attempt("alice settles 'the 500 I owe bob'",
            lambda: q.stitch([alice, bob], {"type": "discharge"},
                             cites=[cite(debt, amount=500, debtor=alice.pub, creditor=bob.pub)]))
print(f"   the refusal hands back the record: amount is {v.record['amount']}")
attempt("alice settles a debt to carol that never existed",
        lambda: q.stitch([alice, carol], {"type": "discharge"},
                         cites=[cite(H("imagined"), amount=200, debtor=alice.pub, creditor=carol.pub)]))
attempt("LIMIT: alice tells carol 'I owe bob 500' in free text, citing nothing",
        lambda: q.stitch([alice, carol], {"type": "note", "text": "I owe bob 500"}))

say("The clock fires for a debt the mind has forgotten")
while not q.due(clock.n):
    clock.tick()
sid, o = q.due(clock.n)[0]
print(f"   tick {clock.n}: index says {q.rooms[o['debtor']].name} owes {o['amount']}, due tick {o['due']}")
attempt("alice settles 300, citing the record",
        lambda: q.stitch([alice, bob], {"type": "discharge"},
                         cites=[cite(debt, amount=300, debtor=alice.pub, creditor=bob.pub)]))
state(q, clock, alice, bob)

say("A resource is a room with a rule")
dock = Resource("dock-7")
q.birth(operator, dock)
attempt("alice claims dock-7", lambda: q.stitch([alice, dock], {"type": "claim", "holder": alice.pub}))
attempt("bob claims dock-7", lambda: q.stitch([bob, dock], {"type": "claim", "holder": bob.pub}))

say("A lying custodian shows two claimants two logs")
berth = Resource("berth-2")
q.birth(operator, berth)
saved = (berth.head, berth.seq)
q.stitch([bob, berth], {"type": "claim", "holder": bob.pub})
berth.head, berth.seq = saved
q.stitch([carol, berth], {"type": "claim", "holder": carol.pub})
print(f"   bob and carol each hold a signed receipt; alarms so far: {len(bob.alarms) + len(carol.alarms)}")
proof = gossip(bob, carol)
print(f"   they compare receipts: equivocation proven = {equivocation(*proof)} "
      f"(two entries signed by {q.rooms[proof[0]['room']].name} at seq {proof[0]['seq']})")

say("A colluding pair backdates")
attempt("alice and bob sign 'we agreed this at tick 2'",
        lambda: q.stitch([alice, bob], {"type": "note"}, after=first_tick, claimed_time=2))

say("A room rewrites its own log")
receipt = bob.seen[(alice.pub, receipts[alice.pub]["seq"])]
print(f"   bob holds alice's receipt for the original debt (seq {receipt['seq']})")
alice.store.items.clear(); alice.head, alice.seq = None, 0
alice.note("a tidier history")
verify_view(alice.view())
print("   alice's new log verifies on its own")
attempt("bob audits alice's log against the receipt she signed",
        lambda: q.audit(receipt, alice.head, alice.store.get))
