# quilt-room-poc

**PROTOTYPE. Throwaway code that answers a question. Not hardened, not for production.**

The question: does the quilt room protocol hold together when it is actually run? The design claims
that three things (rooms, stitches, custodians) and one rule (every commitment cites its premises by
hash, and a mechanism checks the citation) are enough for agents that are honest but lossy. This repo
runs that claim with real Ed25519 signatures and SHA-256 hash links, and attacks it.

The answers are in [NOTES.md](NOTES.md). The numbers are in [results/](results/).

## Run it

Needs Python 3.11+ and two packages.

```
pip install cryptography pytest
python3 demo.py                   # one walk through the whole protocol, about a second
python3 -m pytest -q              # 38 attacks, about a second
python3 tests/mutate.py           # remove each guard in turn, confirm a test notices; about 20 s
python3 -m experiments.fork       # custodian fork detection; about 10 minutes on 2 cores
python3 -m experiments.fork --quick   # the same at a tenth of the trials; about 1 minute
python3 -m experiments.fleet      # honest-but-lossy fleet under four memory regimes; about 2 minutes
```

Both experiments use fixed seeds, so a rerun reproduces every number in `results/` (run time aside).

## What is where

| Path | What it is |
| --- | --- |
| `quilt/core.py` | Rooms, hash-linked signed logs, stitches, declared compaction, the citation checker, the obligation index, the clock room, resource rooms, leases, lineage, audit. About 600 lines. |
| `quilt/tiers.py` | The three custody tiers as signature counting: single custodian, unanimous, quorum. |
| `tests/test_attacks.py` | Every claim from the design conversation as an attack. Tests named `test_limit_*` assert that a known hole is still open. |
| `tests/mutate.py` | Removes 28 guards one at a time and checks the tests catch each removal. |
| `experiments/fork.py` | How long a forking custodian goes unnoticed, by fleet size, stitch rate, witnesses, org seam, victim activity and uneven fleets. |
| `experiments/fleet.py` | Twelve rooms making and settling debts while their minds forget, under four memory regimes. |
| `demo.py` | A narrated run that prints what each mechanism says. |

## What this does not show

- **No network and no concurrency.** Everything runs in one process, one stitch at a time.
- **No real minds.** The lossy minds are random-error models with assumed fault rates, not language models.
- **No consensus protocol.** `tiers.py` is the counting argument for who can fork and who can stall. It has no timing, no leader change and no message loss.
- **One fleet.** The archive is a single in-memory store. Cross-org retention is argued in the tests, not built.
- **No fixed topology.** The fork experiment pairs rooms at random. One scenario makes activity uneven, but there is never a fixed graph of who can reach whom.
